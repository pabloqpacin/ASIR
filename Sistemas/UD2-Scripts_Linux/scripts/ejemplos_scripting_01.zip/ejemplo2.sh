#!/bin/bash

echo -n "La Suma es "
expr $1 + $2