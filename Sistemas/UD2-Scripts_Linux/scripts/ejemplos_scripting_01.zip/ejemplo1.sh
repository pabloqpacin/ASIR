#!/bin/bash

nombre=$1
apellido1=$2
apellido2=$3

echo "Hola $apellido1 $apellido2, $nombre"

# EJECUTAR COMO: ./ejemplo1.sh pablo quevedo pacin
