#!/bin/bash

archivo='/tmp/script03.txt'

while true; do
    read -p "Leo palabras y las redirijo a '$archivo' hasta que escribas ':q': " opt
    if [[ $opt == ':q' ]]; then
        break
    fi
    echo "$opt" >> $archivo
done
