#!/bin/bash

if [ ! $1 ]
    then echo "Error: falta parámetro \$1"; exit 0
elif [ ! $2 ]
    then echo "Error: falta parámetro \$2"; exit 0
fi

echo "-- Número 1: $1 --"
echo "-- Número 2: $2 --"

echo "Media: $(echo "scale=2; ($1 + $2) / 2" | bc)"

if [ $1 -gt $2 ]; then
    echo "$1 es mayor que $2"
elif [ $1 -lt $2 ]; then
    echo "$1 es menor que $2"
else
    echo "O son iguales o no son números o hay un problema"
fi
