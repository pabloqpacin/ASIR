#!/bin/bash


precio=25
descuento=10

echo "Un viaje en tren son $precio euros. Comprado con ida y vuelta, se hace un descuento del $descuento%"
read -p "¿Compras ida (1) o ida y vuelta (2)? " opt

ida_vuelta() {
    suma=$((precio * 2))
    importe=$((suma - (suma * 10 / 100) ))
    echo "Importe final: $importe"
}

case $opt in
    '1') echo "Importe final: $precio" ;;
    '2') ida_vuelta ;;
    *) echo "Ha ocurrido un error" ;;
esac
