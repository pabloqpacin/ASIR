#!/bin/bash

while true; do
    read -p "Leo palabras hasta que escribas ':q': " opt
    if [[ $opt == ':q' ]]; then
        break
    fi
done
