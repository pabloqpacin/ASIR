#!/bin/bash

if [ ! $1 ]
    then echo "No has pasado \$1"
    else echo "Sí has pasado \$1"
fi

if [ -e $1 ]
    then echo "La ruta '$1' existe"
    else echo "La ruta '$1' NO existe"
fi
